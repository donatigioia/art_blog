<?php
die();
?>